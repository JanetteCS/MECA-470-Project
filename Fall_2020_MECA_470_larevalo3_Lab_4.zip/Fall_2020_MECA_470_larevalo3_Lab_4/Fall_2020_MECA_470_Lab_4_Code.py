import numpy as np
import sim
import time
import sys
import ikpy 

#Trying to connect
sim.simxFinish(-1)
your_IP="192.168.0.7"
clientID = sim.simxStart(your_IP,19999,True,True,10000,5)
if clientID != -1:
 print("Connected to remote API server")
else:
 print("Not connected to remote API server")
 sys.exit ("could not connect")
 #-----Start the Paused Simulation
err_code = sim.simxStartSimulation(clientID,sim.simx_opmode_oneshot)
#-----Initialize Joint Handles---------
err_code,j1 = sim.simxGetObjectHandle(clientID,"BL_Leg_Actuator",sim.simx_opmode_blocking)
err_code,j2 = sim.simxGetObjectHandle(clientID,"BR_Leg_Actuator",sim.simx_opmode_blocking)
err_code,j3 = sim.simxGetObjectHandle(clientID,"FL_Leg_Actuator",sim.simx_opmode_blocking)
err_code,j4 = sim.simxGetObjectHandle(clientID,"FR_Leg_Actuator",sim.simx_opmode_blocking)
err_code,j5 = sim.simxGetObjectHandle(clientID,"BL_Knee",sim.simx_opmode_blocking)
err_code,j6 = sim.simxGetObjectHandle(clientID,"BR_Knee",sim.simx_opmode_blocking)
err_code,j7 = sim.simxGetObjectHandle(clientID,"FL_Knee",sim.simx_opmode_blocking)
err_code,j8 = sim.simxGetObjectHandle(clientID,"FR_Knee",sim.simx_opmode_blocking)
t = time.time()
while (time.time()-t)<30:
    a1 = 15
    a2 = 0
    a3 = -15


    #Moving Front Left Leg

    #Upper Leg MOV1
    pos_val = a1
 #robot.animate(stances=f, frame_rate=30, unit='deg')
    err_code = sim.simxSetJointTargetVelocity (clientID, j3,pos_val,sim.simx_opmode_streaming) # set the postion of J1
    time.sleep(35) #wait a short amount of time

    pos_val = a2
 #robot.animate(stances=f, frame_rate=30, unit='deg')
    err_code = sim.simxSetJointTargetVelocity (clientID, j3,pos_val,sim.simx_opmode_streaming) # set the postion of J1
    time.sleep(1) #wait a short amount of time

    #Knee Mov 1 
    pos_val = a3
 #robot.animate(stances=f, frame_rate=30, unit='deg')
    err_code = sim.simxSetJointTargetVelocity (clientID, j7,pos_val,sim.simx_opmode_streaming) # set the postion of J1
    time.sleep(25) #wait a short amount of time

    pos_val = a2
 #robot.animate(stances=f, frame_rate=30, unit='deg')
    err_code = sim.simxSetJointTargetVelocity (clientID, j7,pos_val,sim.simx_opmode_streaming) # set the postion of J1
    time.sleep(1) #wait a short amount of time

    #Upper Leg MOV 2
    pos_val = a3
 #robot.animate(stances=f, frame_rate=30, unit='deg')
    err_code = sim.simxSetJointTargetVelocity (clientID, j3,pos_val,sim.simx_opmode_streaming) # set the postion of J1
    time.sleep(20) #wait a short amount of time
   
    pos_val = a2
 #robot.animate(stances=f, frame_rate=30, unit='deg')
    err_code = sim.simxSetJointTargetVelocity (clientID, j3,pos_val,sim.simx_opmode_streaming) # set the postion of J1
    time.sleep(1) #wait a short amount of time

   #Knee Mov 2
    pos_val = a1
 #robot.animate(stances=f, frame_rate=30, unit='deg')
    err_code = sim.simxSetJointTargetVelocity (clientID, j7,pos_val,sim.simx_opmode_streaming) # set the postion of J1
    time.sleep(20) #wait a short amount of time
   
    pos_val = a2
 #robot.animate(stances=f, frame_rate=30, unit='deg')
    err_code = sim.simxSetJointTargetVelocity (clientID, j7,pos_val,sim.simx_opmode_streaming) # set the postion of J1
    time.sleep(1) #wait a short amount of time



        #Moving Front Right Leg

    #Upper Leg MOV1
    pos_val = a1
 #robot.animate(stances=f, frame_rate=30, unit='deg')
    err_code = sim.simxSetJointTargetVelocity (clientID, j4,pos_val,sim.simx_opmode_streaming) # set the postion of J1
    time.sleep(35) #wait a short amount of time

    pos_val = a2
 #robot.animate(stances=f, frame_rate=30, unit='deg')
    err_code = sim.simxSetJointTargetVelocity (clientID, j4,pos_val,sim.simx_opmode_streaming) # set the postion of J1
    time.sleep(1) #wait a short amount of time

    #Knee Mov 1 
    pos_val = a3
 #robot.animate(stances=f, frame_rate=30, unit='deg')
    err_code = sim.simxSetJointTargetVelocity (clientID, j8,pos_val,sim.simx_opmode_streaming) # set the postion of J1
    time.sleep(25) #wait a short amount of time

    pos_val = a2
 #robot.animate(stances=f, frame_rate=30, unit='deg')
    err_code = sim.simxSetJointTargetVelocity (clientID, j8,pos_val,sim.simx_opmode_streaming) # set the postion of J1
    time.sleep(1) #wait a short amount of time

    #Upper Leg MOV 2
    pos_val = a3
 #robot.animate(stances=f, frame_rate=30, unit='deg')
    err_code = sim.simxSetJointTargetVelocity (clientID, j4,pos_val,sim.simx_opmode_streaming) # set the postion of J1
    time.sleep(20) #wait a short amount of time
   
    pos_val = a2
 #robot.animate(stances=f, frame_rate=30, unit='deg')
    err_code = sim.simxSetJointTargetVelocity (clientID, j4,pos_val,sim.simx_opmode_streaming) # set the postion of J1
    time.sleep(1) #wait a short amount of time

   #Knee Mov 2
    pos_val = a1
 #robot.animate(stances=f, frame_rate=30, unit='deg')
    err_code = sim.simxSetJointTargetVelocity (clientID, j8,pos_val,sim.simx_opmode_streaming) # set the postion of J1
    time.sleep(25) #wait a short amount of time
   
    pos_val = a2
 #robot.animate(stances=f, frame_rate=30, unit='deg')
    err_code = sim.simxSetJointTargetVelocity (clientID, j8,pos_val,sim.simx_opmode_streaming) # set the postion of J1
    time.sleep(1) #wait a short amount of time



    #Moving Back Left Leg

    #Upper Leg MOV1
    pos_val = a1
 #robot.animate(stances=f, frame_rate=30, unit='deg')
    err_code = sim.simxSetJointTargetVelocity (clientID, j1,pos_val,sim.simx_opmode_streaming) # set the postion of J1
    time.sleep(25) #wait a short amount of time

    pos_val = a2
 #robot.animate(stances=f, frame_rate=30, unit='deg')
    err_code = sim.simxSetJointTargetVelocity (clientID, j1,pos_val,sim.simx_opmode_streaming) # set the postion of J1
    time.sleep(1) #wait a short amount of time

    #Knee Mov 1 
    pos_val = a1
 #robot.animate(stances=f, frame_rate=30, unit='deg')
    err_code = sim.simxSetJointTargetVelocity (clientID, j5,pos_val,sim.simx_opmode_streaming) # set the postion of J1
    time.sleep(15) #wait a short amount of time

    pos_val = a2
 #robot.animate(stances=f, frame_rate=30, unit='deg')
    err_code = sim.simxSetJointTargetVelocity (clientID, j5,pos_val,sim.simx_opmode_streaming) # set the postion of J1
    time.sleep(1) #wait a short amount of time

    #Upper Leg MOV 2
    pos_val = a3
 #robot.animate(stances=f, frame_rate=30, unit='deg')
    err_code = sim.simxSetJointTargetVelocity (clientID, j1,pos_val,sim.simx_opmode_streaming) # set the postion of J1
    time.sleep(25) #wait a short amount of time
   
    pos_val = a2
 #robot.animate(stances=f, frame_rate=30, unit='deg')
    err_code = sim.simxSetJointTargetVelocity (clientID, j1,pos_val,sim.simx_opmode_streaming) # set the postion of J1
    time.sleep(1) #wait a short amount of time

   #Knee Mov 2
    pos_val = a3
 #robot.animate(stances=f, frame_rate=30, unit='deg')
    err_code = sim.simxSetJointTargetVelocity (clientID, j5,pos_val,sim.simx_opmode_streaming) # set the postion of J1
    time.sleep(15) #wait a short amount of time
   
    pos_val = a2
 #robot.animate(stances=f, frame_rate=30, unit='deg')
    err_code = sim.simxSetJointTargetVelocity (clientID, j5,pos_val,sim.simx_opmode_streaming) # set the postion of J1
    time.sleep(1) #wait a short amount of time


    #Moving Back Right Leg

    #Upper Leg MOV1
    pos_val = a3
 #robot.animate(stances=f, frame_rate=30, unit='deg')
    err_code = sim.simxSetJointTargetVelocity (clientID, j2,pos_val,sim.simx_opmode_streaming) # set the postion of J1
    time.sleep(40) #wait a short amount of time

    pos_val = a2
 #robot.animate(stances=f, frame_rate=30, unit='deg')
    err_code = sim.simxSetJointTargetVelocity (clientID, j2,pos_val,sim.simx_opmode_streaming) # set the postion of J1
    time.sleep(1) #wait a short amount of time

    #Knee Mov 1 
    pos_val = a3
 #robot.animate(stances=f, frame_rate=30, unit='deg')
    err_code = sim.simxSetJointTargetVelocity (clientID, j6,pos_val,sim.simx_opmode_streaming) # set the postion of J1
    time.sleep(25) #wait a short amount of time

    pos_val = a2
 #robot.animate(stances=f, frame_rate=30, unit='deg')
    err_code = sim.simxSetJointTargetVelocity (clientID, j6,pos_val,sim.simx_opmode_streaming) # set the postion of J1
    time.sleep(1) #wait a short amount of time

    #Upper Leg MOV 2
    pos_val = a1
 #robot.animate(stances=f, frame_rate=30, unit='deg')
    err_code = sim.simxSetJointTargetVelocity (clientID, j2,pos_val,sim.simx_opmode_streaming) # set the postion of J1
    time.sleep(30) #wait a short amount of time
   
    pos_val = a2
 #robot.animate(stances=f, frame_rate=30, unit='deg')
    err_code = sim.simxSetJointTargetVelocity (clientID, j2,pos_val,sim.simx_opmode_streaming) # set the postion of J1
    time.sleep(1) #wait a short amount of time

   #Knee Mov 2
    pos_val = a3
 #robot.animate(stances=f, frame_rate=30, unit='deg')
    err_code = sim.simxSetJointTargetVelocity (clientID, j6,pos_val,sim.simx_opmode_streaming) # set the postion of J1
    time.sleep(10) #wait a short amount of time
   
    pos_val = a2
 #robot.animate(stances=f, frame_rate=30, unit='deg')
    err_code = sim.simxSetJointTargetVelocity (clientID, j6,pos_val,sim.simx_opmode_streaming) # set the postion of J1
    time.sleep(1) #wait a short amount of time